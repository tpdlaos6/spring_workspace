package com.sosuin.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sosuin.domain.BoardVO;
import com.sosuin.domain.Paging;

public interface BoardMapper {
	//목록
	public List<BoardVO> getList();
	public List<BoardVO> getList2(@Param("categoryName") String categoryName);
	//상세보기
	public BoardVO read(Long bno);
	//가장 최신글을 불러오기위한 번호 구하기
	public int getBno(BoardVO board);
	public int getBno2(BoardVO board,@Param("categoryName") String categoryName);

		
	//새 글을 등록하는 메소드
	public void insert(BoardVO board);
	
	// 새글을 등록하면서 해당 게시글의 키 값을 반환하는 메소드
	//DB의 Primary Key 값을 가져올 때 사용
	public Integer insertSelectKey(BoardVO board);
	
	//삭제
	public int delete(Long bno);
	
	//수정
	public int modify(BoardVO board);
	
	//전체글수, 페이징처리를 위해 사용
	public int getTotalCount(Paging paging);
	
	//페이징 처리를 적용하여 게시글목록을 가져오는 메소드
	//paging 객체를 통해 페이지 번호와 페이지당 개수 등의 정보를 전달
	// 상위 목록과 동일한 걸 불러오니 오버로딩을 사용하면 좋다.
	public List<BoardVO> getListWithPaging(Paging paging);

}
