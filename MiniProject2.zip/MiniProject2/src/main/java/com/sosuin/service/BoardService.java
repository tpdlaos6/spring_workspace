package com.sosuin.service;

import java.util.List;

import com.sosuin.domain.BoardVO;
import com.sosuin.domain.Paging;

public interface BoardService {
	//목록
	public List<BoardVO> getList();
	//목록
	public List<BoardVO> getList2(String categoryName);
	//상세보기
	public BoardVO get(Long bno);
	//최신글을 불러오기 위한 숫자 구하기
	public int getBno(BoardVO board);
	public int getBno2(BoardVO board,String categoryName);
	
	
	//등록
	public void register(BoardVO board);	
	//삭제
	public boolean remove(Long bno);
	//수정
	public boolean modify(BoardVO board);
	//전체글수
	public int getTotal(Paging paging);
	//목록 with paging
	public List<BoardVO> getList(Paging paging); //overloading
}
