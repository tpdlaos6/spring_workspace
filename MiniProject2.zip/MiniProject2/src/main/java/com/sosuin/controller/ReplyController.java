package com.sosuin.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.sosuin.domain.Paging;
import com.sosuin.domain.ReplyPageDTO;
import com.sosuin.domain.ReplyVO;
import com.sosuin.service.ReplyService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@RequestMapping("/replies")
@RestController
@Log4j
public class ReplyController {
	private ReplyService service;

	//등록
	
	@PostMapping("/new")
	public String register(ReplyVO vo, RedirectAttributes rttr) {
	    service.register(vo);
	    rttr.addFlashAttribute("result", vo.getRno());
	    return "redirect:/get";
	}

//	@PostMapping(value="/new",consumes="application/json",produces= {MediaType.TEXT_PLAIN_VALUE})
//	public ResponseEntity<String> create(@RequestBody ReplyVO vo){
//		int insertCount=service.register(vo);
//		return insertCount==1?new ResponseEntity<>("success",HttpStatus.OK):new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
//	}
	
	//상세보기
//	@GetMapping(value="/{rno}")
//	public ResponseEntity<ReplyVO> get(@PathVariable("rno") Long rno){
//		return new ResponseEntity<>(service.get(rno), HttpStatus.OK);
//	}
	
	//수정
//	@RequestMapping(value="/{rno}",method={RequestMethod.PUT,RequestMethod.PATCH})
//	public ResponseEntity<String> modify(@RequestBody ReplyVO vo,@PathVariable("rno") Long rno){
//		vo.setBno(rno);
//		return service.modify(vo)==1?new ResponseEntity<>("success",HttpStatus.OK):
//									new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR); 
//	}
	
	//삭제
//	@DeleteMapping(value="/{rno}",produces= {MediaType.TEXT_PLAIN_VALUE}) // text 전송. success라고 보낼 예정.
//	public ResponseEntity<String> remove(@PathVariable("rno") Long rno){		
//		return service.remove(rno)==1?new ResponseEntity<>("success",HttpStatus.OK):
//									new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
//	}
	
	//목록
	@GetMapping("/pages/{bno}/{page}")
	public String getList(@PathVariable("page") int page,@PathVariable("bno") Long bno, Model model){
		Paging pag=new Paging(page,10);
		ReplyPageDTO replayPageDTO=service.getListPage(pag, bno);
		model.addAttribute("replayPageDTO", replayPageDTO);
		return "get";
	}


//	public ResponseEntity<ReplyPageDTO> getList(@PathVariable("page") int page,@PathVariable("bno") Long bno){
//		Paging paging=new Paging(page,10);
//		return new ResponseEntity<>(service.getListPage(paging, bno),HttpStatus.OK);
//	}
}


