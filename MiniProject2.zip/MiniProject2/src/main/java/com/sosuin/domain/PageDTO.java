package com.sosuin.domain;

public class PageDTO {

}
