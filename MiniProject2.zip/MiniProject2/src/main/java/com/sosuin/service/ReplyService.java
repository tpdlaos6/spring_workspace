package com.sosuin.service;

import java.util.List;

import com.sosuin.domain.Paging;
import com.sosuin.domain.ReplyPageDTO;
import com.sosuin.domain.ReplyVO;

public interface ReplyService {
	
	//등록
	public int register(ReplyVO vo);
	//상세보기
	public ReplyVO get(Long rno);
	//삭제
	public int remove(Long rno);
	//수정
	public int modify(ReplyVO vo);
	//목록 
	public List<ReplyVO> getList(Paging paging, Long bno);
	//댓글 with Paging
	public ReplyPageDTO getListPage(Paging paging, Long bno);


}
