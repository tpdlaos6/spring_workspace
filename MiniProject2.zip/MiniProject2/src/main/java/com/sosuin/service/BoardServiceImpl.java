package com.sosuin.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sosuin.domain.BoardVO;
import com.sosuin.domain.Paging;
import com.sosuin.mapper.BoardMapper;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class BoardServiceImpl implements BoardService{

	//자동주입
	private BoardMapper mapper;
	
	//목록
	@Override
	public List<BoardVO> getList() {
		
		return mapper.getList();
	}

	//상세보기
	@Override
	public BoardVO get(Long bno) {
		return mapper.read(bno);
	}
	
	//최신글 불러오기 위한 번호 찾기
	@Override
	public int getBno(BoardVO board) {
		return mapper.getBno(board);
	}

	@Override
	public List<BoardVO> getList2(String categoryName) {
		return mapper.getList2(categoryName);
	}


	@Override
	public int getBno2(BoardVO board, String categoryName) {
		// TODO Auto-generated method stub
		return mapper.getBno2(board, categoryName);
	}

	@Override
	public void register(BoardVO board) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean remove(Long bno) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean modify(BoardVO board) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getTotal(Paging paging) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<BoardVO> getList(Paging paging) {
		// TODO Auto-generated method stub
		return null;
	}

	


}
