package com.sosuin.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sosuin.domain.BoardVO;
import com.sosuin.service.BoardService;

import lombok.AllArgsConstructor;



@Controller
@RequestMapping("/board/*")
@AllArgsConstructor
public class BoardController {
	
	
	
	//자동주입
	private BoardService service;
	
	@GetMapping("/get")
	public void get(@RequestParam(defaultValue = "0") Long bno, Model model, BoardVO board, @RequestParam(value="categoryName", defaultValue = "All") String categoryName) {
		
		if(categoryName.equals("All") || categoryName.equals("")) {
			if(bno == 0 || bno.equals("0")) {
				bno=(long) service.getBno(board);
			};
			model.addAttribute("list",service.getList());
			model.addAttribute("board",service.get(bno));
		}else {
			if(bno == 0 || bno.equals("0") ) {
				bno=(long) service.getBno2(board, categoryName);
			};
			model.addAttribute("list",service.getList2(categoryName));
			model.addAttribute("board",service.get(bno));
		}
		
	}
	
}
