package com.sosuin.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Setter
@Getter
public class Paging {
	
	private int pageNum=1; // page 번호
	private int amount=10; // 데이터가 몇개냐
	
	public Paging(int pageNum, int amount) {
		this.pageNum=pageNum;
		this.amount=amount;
	}
	
	//mybatis의 getSkip()함수로 페이징 처리
	public int getSkip() { 
		return (this.pageNum-1)*this.amount;
	}
	

}
