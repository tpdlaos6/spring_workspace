package com.sosuin.mapper;


public class BoardMapperTest {


}