package com.sosuin.domain;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BoardVO {
	private Long bno;
	private String id;
	private String title;
	private String categoryName;
	private int readcount;
	private String content;
	private String img;
	private Date postdate;
}
